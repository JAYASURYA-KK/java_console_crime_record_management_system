# Crime Record Management System

A console-based Java application for managing criminal records with role-based access control and MongoDB integration.

## Prerequisites

1. **Java 11 or higher** - Make sure Java is installed and `JAVA_HOME` is set
2. **Maven 3.6+** - For building and running the application
3. **MongoDB** - Running on localhost:27017 (default port)

## Setup Instructions

### 1. Start MongoDB
Make sure MongoDB is running on your system:
```bash
mongod
```

### 2. Initialize Database
Run the MongoDB setup script to create collections and sample data:
```bash
mongo < scripts/mongodb-setup.js
```

### 3. Compile the Application

**Using Maven:**
```bash
mvn clean compile
```

**On Linux/Mac:**
```bash
chmod +x scripts/compile.sh
./scripts/compile.sh
```

**On Windows:**
```cmd
scripts\compile.bat
```

### 4. Run the Application (Console)
```bash
# Run the console interface
mvn exec:java -Dexec.mainClass="com.crimemanagement.CrimeManagementApplication"
```

**Alternative Scripts:**

**On Linux/Mac:**
```bash
chmod +x scripts/run.sh
./scripts/run.sh  # Runs console application
```

**On Windows (CMD):**
```cmd
scripts\run.bat  # Runs console application
```

**On Windows (PowerShell):**
```powershell
Set-Location E:\inteconsole\console; mvn -q -DskipTests clean package
java -cp "target/classes;target/dependency/*" com.crimemanagement.CrimeManagementApplication
```

## Default Users

The system comes with pre-configured users:

| Email | Password | Role |
|----------|----------|------|
| admin@gmail.com | admin123 | Admin |
| special@gmail.com | special123 | Special User |
| user@gmail.com | user123 | Normal User |

## Features

- **Role-based Access Control**: Admin, Special User, and Normal User roles
- **Crime Record Management**: Add, edit, delete, and view crime records
- **Advanced Search**: Console search by ID, name, or city using HashMap/HashSet indexes
- **Photo Info**: Optional path validation via `PhotoService` (console only)
- **Newest-first ordering**: Latest records shown first (Stack-based display)
- **Data Structures**: Uses ArrayList, Stack, HashMap, and HashSet for efficient operations
- **MongoDB Integration**: Persistent storage with MongoDB database
- **Input Validation**: Comprehensive validation and error handling

## Usage

### Console Interface
1. Start the application using one of the run commands above
2. Login with one of the default users
3. Navigate through the role-specific menus:
   - **Admin Menu**: Add users, manage crime records, view/search records
   - **Special User Menu**: Manage crime records, view/search records  
   - **Normal User Menu**: View and search crime records

### Crime Record View (Console)
Use the console "Crime Record View" to:
 - View all records (latest first)
 - Search by: ID, Criminal Name, City

## Menu Options by Role

### Admin Menu
1. Add User
2. Add Crime Record  
3. Edit Crime Record
4. Delete Crime Record
5. Crime Record View (Console)
6. Logout

### Special User Menu
1. Add Crime Record
2. Edit Crime Record  
3. Delete Crime Record
4. Crime Record View (Console)
5. Logout

### Normal User Menu
1. Crime Record View (Console)
2. Logout

## Project Structure

```
src/main/java/com/crimemanagement/
├── config/          # Database configuration
├── controller/      # (Removed) Web controllers
├── exception/       # Custom exceptions
├── model/          # Data models (User, Crime)
├── service/        # Business logic services
├── ui/             # Console user interface
└── util/           # Utility classes (`InputValidator`, `CrimeInputHelper`)

src/main/resources/
├── templates/      # (Removed)
└── static/         # (Removed)

scripts/            # Build and run scripts
```

## Technical Details

- **Backend**: Java console application
- **Database**: MongoDB with Java driver
- **Data Structures**: ArrayList (in-memory storage), Stack (latest-first display),
  HashMap (indexes for ID/name/city), HashSet (unique city set)
- **Architecture**: Console application with MongoDB persistence

## Data Structures Used (Where and Why)

- ArrayList (`CrimeService.crimeList`):
  - Stores all `Crime` records in memory for iteration and simple operations.
  - Chosen for contiguous storage and fast iteration.

- Stack (`CrimeService.crimeStack`):
  - Maintains latest-first viewing order using LIFO semantics when displaying records.
  - Simplifies "newest on top" listing in the console.

- HashMap (`SearchService`):
  - `idIndex: HashMap<String, Crime>` for O(1) record lookup by ID.
  - `nameIndex: HashMap<String, List<Crime>>` for fast name searches (exact and partial over keys).
  - `cityIndex: HashMap<String, List<Crime>>` for fast city searches (exact and partial over keys).

- HashSet (`SearchService.uniqueCities`):
  - Tracks unique cities encountered; useful for quick membership checks or future features.

## Troubleshooting

1. **MongoDB Connection Issues**: Ensure MongoDB is running on localhost:27017
2. **Port Already in Use**: When launching from the console, the app auto-selects a free port. When running `mvn spring-boot:run` directly, ensure 8080 is free or set a different port via `-Dserver.port=<port>`.
3. **PowerShell '&&' Not Supported**: Use a semicolon `;` to chain commands in PowerShell.
4. **Java Version**: Ensure you're using Java 11 or higher
5. **Maven Issues**: Run `mvn clean install` to resolve dependency issues

## Changes from Previous Version

- **Removed**: Web interface, WebSocket updates, and related templates/resources
- **Removed**: Data structures demo and unused utilities
- **Added**: Console-only "Crime Record View" with ID/Name/City search
