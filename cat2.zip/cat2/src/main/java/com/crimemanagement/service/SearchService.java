package com.crimemanagement.service;

import com.crimemanagement.model.Crime;

import java.util.*;

public class SearchService {
    private final CrimeService crimeService;
    private final HashMap<String, Crime> idIndex;
    private final HashMap<String, List<Crime>> nameIndex;
    private final HashMap<String, List<Crime>> cityIndex;
    private final HashSet<String> uniqueCities;
    
    public SearchService() {
        this.crimeService = SharedServiceHolder.getCrimeService() != null
                ? SharedServiceHolder.getCrimeService()
                : new CrimeService();
        this.idIndex = new HashMap<>();
        this.nameIndex = new HashMap<>();
        this.cityIndex = new HashMap<>();
        this.uniqueCities = new HashSet<>();
        buildSearchIndexes();
    }
    
    public List<Crime> searchById(String id) {
        Crime crime = idIndex.get(id);
        if (crime == null) return Collections.emptyList();
        return List.of(crime);
    }
    
    public List<Crime> searchByName(String name) {
        if (name == null) return Collections.emptyList();
        List<Crime> exactMatches = nameIndex.get(name.toLowerCase());
        if (exactMatches != null && !exactMatches.isEmpty()) {
            return new ArrayList<>(exactMatches);
        }
        // partial match fallback using index keys
        List<Crime> results = new ArrayList<>();
        String needle = name.toLowerCase();
        for (Map.Entry<String, List<Crime>> entry : nameIndex.entrySet()) {
            if (entry.getKey().contains(needle)) {
                results.addAll(entry.getValue());
            }
        }
        return results;
    }
    
    public List<Crime> searchByCity(String city) {
        if (city == null) return Collections.emptyList();
        List<Crime> exactMatches = cityIndex.get(city.toLowerCase());
        if (exactMatches != null && !exactMatches.isEmpty()) {
            return new ArrayList<>(exactMatches);
        }
        List<Crime> results = new ArrayList<>();
        String needle = city.toLowerCase();
        for (Map.Entry<String, List<Crime>> entry : cityIndex.entrySet()) {
            if (entry.getKey().contains(needle)) {
                results.addAll(entry.getValue());
            }
        }
        return results;
    }
    
    public void displaySearchResults(List<Crime> results, String searchLabel) {
        if (results.isEmpty()) {
            System.out.println("No records found for: " + searchLabel);
            return;
        }
        System.out.println("\n=== SEARCH RESULTS (" + searchLabel + ") ===");
        for (int i = 0; i < results.size(); i++) {
            Crime crime = results.get(i);
            System.out.println("\n" + (i + 1) + ". Crime Record:");
            displayCrimeDetails(crime);
        }
    }
    
    public void displaySearchMenu() {
        System.out.println("\n=== CRIME RECORD VIEW ===");
        System.out.println("1. View All (Latest First)");
        System.out.println("2. Search by ID");
        System.out.println("3. Search by Criminal Name");
        System.out.println("4. Search by City");
        System.out.println("5. Back to Main Menu");
    }
    
    public void performSearch(int option) {
        List<Crime> results = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        switch (option) {
            case 1:
                crimeService.displayAllCrimes();
                return;
            case 2:
                System.out.print("Enter ID: ");
                results = searchById(scanner.nextLine().trim());
                displaySearchResults(results, "ID");
                break;
            case 3:
                System.out.print("Enter name: ");
                results = searchByName(scanner.nextLine().trim());
                displaySearchResults(results, "Name");
                break;
            case 4:
                System.out.print("Enter city: ");
                results = searchByCity(scanner.nextLine().trim());
                displaySearchResults(results, "City");
                break;
            default:
                System.out.println("Invalid option.");
                return;
        }
    }
    
    private void buildSearchIndexes() {
        idIndex.clear();
        nameIndex.clear();
        cityIndex.clear();
        uniqueCities.clear();
        for (Crime crime : crimeService.getAllCrimes()) {
            if (crime.getId() != null) {
                idIndex.put(crime.getId(), crime);
            }
            if (crime.getName() != null) {
                String key = crime.getName().toLowerCase();
                nameIndex.computeIfAbsent(key, k -> new ArrayList<>()).add(crime);
            }
            if (crime.getCity() != null) {
                String key = crime.getCity().toLowerCase();
                cityIndex.computeIfAbsent(key, k -> new ArrayList<>()).add(crime);
                uniqueCities.add(key);
            }
        }
    }
    
    private void displayCrimeDetails(Crime crime) {
        System.out.println("   ID: " + crime.getId());
        System.out.println("   Name: " + crime.getName());
        System.out.println("   City: " + crime.getCity());
        System.out.println("   Crime Type: " + crime.getCrimeType());
        System.out.println("   Details: " + crime.getDetails());
        System.out.println("   Photo Path: " + crime.getPhotoPath());
        System.out.println("   Created: " + crime.getCreatedAt());
        System.out.println("   " + "-".repeat(50));
    }
}
