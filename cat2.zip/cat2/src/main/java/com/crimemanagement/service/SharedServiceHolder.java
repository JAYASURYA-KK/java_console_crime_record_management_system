package com.crimemanagement.service;

public class SharedServiceHolder {
    private static CrimeService crimeService;

    public static void setCrimeService(CrimeService service) {
        crimeService = service;
    }

    public static CrimeService getCrimeService() {
        return crimeService;
    }
}